# Retail OS ? Workspace concept 02

This is an offline redesign proposal, not a deployed application update. Financial figures, staff names and records are illustrative. The existing brand mark is retained. No credentials, live database access or API calls are used.

## Structural changes

- Replace the long sidebar with seven top-level workspaces: Home, Operations, Inventory, Purchasing, Reports, Team and Settings.
- Show only the selected workspace's pages in a second navigation row. Detail pages keep their parent highlighted.
- Use a compact mobile bottom navigation plus a More menu. Secondary pages remain available in the horizontal workspace row.
- Keep the POS source as an instant segmented switch. Store and period are explicit context; detail workflows do not offer irrelevant source controls.
- Use one compact metrics strip, a sales chart, a store list and a separate action column on the overview.
- Use full-width tables for reviews, split content and summary panels for documents, and scan-first forms for counting/receiving/transfers.
- Keep quantity and remove controls compact on mobile transfers. Save remains fixed at the bottom.
- Keep CSV upload and record-batch forms in focused dialogs. Show per-product calculation details on demand.
- Keep assistant conversations in a dedicated page or a contextual panel instead of a generic pop-up.

## How to review

Open index.html. Filter by workspace and switch between desktop and mobile. Every card links to its HTML prototype and both screenshots. Navigation links work within the prototype; buttons that would change records show a preview-only message. The gallery is the complete page catalog; the navigation demonstrates the proposed grouping.

Desktop images are rendered at 1440px wide; mobile images show a 390 ? 844 viewport. Pages below the mobile fold remain accessible in their HTML previews. Screenshots cover all 58 existing full-page templates and four extra interaction states. Shared partials are represented within their parent pages.

## Review limits

This proposal focuses on light-mode layouts and information hierarchy. It does not implement application logic, replace current permissions, change POS integrations or deploy any redesign. A production implementation would preserve validated business rules, translations, accessibility behavior and the preferred pure-black dark mode. Illustrative states should not be used as operational reports.

## Validation

All 62 screens rendered at desktop and mobile sizes: 124 screenshots, zero document-level horizontal-overflow failures and zero page script errors. Gallery filtering, device switching and the mobile More menu were checked. Representative dashboard, report, login and transfer screens were visually inspected. Results are recorded in validation.json. This is a layout check, not an accessibility certification or workflow QA.

## Page coverage

| Existing template / state | Design | Desktop | Mobile |
|---|---|---|---|
| dashboard.html | [Overview](pages/dashboard.html) | [PNG](screenshots/dashboard-desktop.png) | [PNG](screenshots/dashboard-mobile.png) |
| dashboard_staff.html | [My day](pages/dashboard_staff.html) | [PNG](screenshots/dashboard_staff-desktop.png) | [PNG](screenshots/dashboard_staff-mobile.png) |
| sales.html | [Sales overview](pages/sales.html) | [PNG](screenshots/sales-desktop.png) | [PNG](screenshots/sales-mobile.png) |
| sales_products.html | [Sales by product](pages/sales_products.html) | [PNG](screenshots/sales_products-desktop.png) | [PNG](screenshots/sales_products-mobile.png) |
| sales_product.html | [1340 Hand Towel](pages/sales_product.html) | [PNG](screenshots/sales_product-desktop.png) | [PNG](screenshots/sales_product-mobile.png) |
| sales_tx.html | [Transactions](pages/sales_tx.html) | [PNG](screenshots/sales_tx-desktop.png) | [PNG](screenshots/sales_tx-mobile.png) |
| sales_tx_detail.html | [Receipt #BT-10248](pages/sales_tx_detail.html) | [PNG](screenshots/sales_tx_detail-desktop.png) | [PNG](screenshots/sales_tx_detail-mobile.png) |
| sales_employees.html | [Sales by employee](pages/sales_employees.html) | [PNG](screenshots/sales_employees-desktop.png) | [PNG](screenshots/sales_employees-mobile.png) |
| performance.html | [Performance](pages/performance.html) | [PNG](screenshots/performance-desktop.png) | [PNG](screenshots/performance-mobile.png) |
| inventory.html | [Inventory](pages/inventory.html) | [PNG](screenshots/inventory-desktop.png) | [PNG](screenshots/inventory-mobile.png) |
| counts.html | [Stock counts](pages/counts.html) | [PNG](screenshots/counts-desktop.png) | [PNG](screenshots/counts-mobile.png) |
| count_detail.html | [Count #001](pages/count_detail.html) | [PNG](screenshots/count_detail-desktop.png) | [PNG](screenshots/count_detail-mobile.png) |
| stock_events.html | [Stock changes](pages/stock_events.html) | [PNG](screenshots/stock_events-desktop.png) | [PNG](screenshots/stock_events-mobile.png) |
| stock_event_new.html | [Record a write-off](pages/stock_event_new.html) | [PNG](screenshots/stock_event_new-desktop.png) | [PNG](screenshots/stock_event_new-mobile.png) |
| wastage.html | [Wastage](pages/wastage.html) | [PNG](screenshots/wastage-desktop.png) | [PNG](screenshots/wastage-mobile.png) |
| expiry.html | [Expiry dates](pages/expiry.html) | [PNG](screenshots/expiry-desktop.png) | [PNG](screenshots/expiry-mobile.png) |
| traceability.html | [Stock traceability](pages/traceability.html) | [PNG](screenshots/traceability-desktop.png) | [PNG](screenshots/traceability-mobile.png) |
| transfer_sheets.html | [Transfer sheets](pages/transfer_sheets.html) | [PNG](screenshots/transfer_sheets-desktop.png) | [PNG](screenshots/transfer_sheets-mobile.png) |
| transfer_sheet.html | [TS-00001 → Bantayan](pages/transfer_sheet.html) | [PNG](screenshots/transfer_sheet-desktop.png) | [PNG](screenshots/transfer_sheet-mobile.png) |
| stock_transfers.html | [Stock transfers](pages/stock_transfers.html) | [PNG](screenshots/stock_transfers-desktop.png) | [PNG](screenshots/stock_transfers-mobile.png) |
| stock_transfer_detail.html | [ST-0048](pages/stock_transfer_detail.html) | [PNG](screenshots/stock_transfer_detail-desktop.png) | [PNG](screenshots/stock_transfer_detail-mobile.png) |
| stock_transfer_preview.html | [Review CSV import](pages/stock_transfer_preview.html) | [PNG](screenshots/stock_transfer_preview-desktop.png) | [PNG](screenshots/stock_transfer_preview-mobile.png) |
| replenishment.html | [Auto replenishment](pages/replenishment.html) | [PNG](screenshots/replenishment-desktop.png) | [PNG](screenshots/replenishment-mobile.png) |
| loyverse_replenishment.html | [Auto replenishment](pages/loyverse_replenishment.html) | [PNG](screenshots/loyverse_replenishment-desktop.png) | [PNG](screenshots/loyverse_replenishment-mobile.png) |
| repairs.html | [Repair queue](pages/repairs.html) | [PNG](screenshots/repairs-desktop.png) | [PNG](screenshots/repairs-mobile.png) |
| batches.html | [Order batches](pages/batches.html) | [PNG](screenshots/batches-desktop.png) | [PNG](screenshots/batches-mobile.png) |
| purchase_orders.html | [Purchase orders](pages/purchase_orders.html) | [PNG](screenshots/purchase_orders-desktop.png) | [PNG](screenshots/purchase_orders-mobile.png) |
| po_detail.html | [PO #164](pages/po_detail.html) | [PNG](screenshots/po_detail-desktop.png) | [PNG](screenshots/po_detail-mobile.png) |
| po_draft.html | [New purchase order](pages/po_draft.html) | [PNG](screenshots/po_draft-desktop.png) | [PNG](screenshots/po_draft-mobile.png) |
| po_draft_saved.html | [Saved purchase orders](pages/po_draft_saved.html) | [PNG](screenshots/po_draft_saved-desktop.png) | [PNG](screenshots/po_draft_saved-mobile.png) |
| receiving.html | [Receive PO #164](pages/receiving.html) | [PNG](screenshots/receiving-desktop.png) | [PNG](screenshots/receiving-mobile.png) |
| new_product.html | [New product](pages/new_product.html) | [PNG](screenshots/new_product-desktop.png) | [PNG](screenshots/new_product-mobile.png) |
| new_product_list.html | [New product lists](pages/new_product_list.html) | [PNG](screenshots/new_product_list-desktop.png) | [PNG](screenshots/new_product_list-mobile.png) |
| order_document_edit.html | [Edit items & report](pages/order_document_edit.html) | [PNG](screenshots/order_document_edit-desktop.png) | [PNG](screenshots/order_document_edit-mobile.png) |
| order_document_print.html | [Print / Save PDF](pages/order_document_print.html) | [PNG](screenshots/order_document_print-desktop.png) | [PNG](screenshots/order_document_print-mobile.png) |
| issues.html | [Issues](pages/issues.html) | [PNG](screenshots/issues-desktop.png) | [PNG](screenshots/issues-mobile.png) |
| issue_new.html | [Report an issue](pages/issue_new.html) | [PNG](screenshots/issue_new-desktop.png) | [PNG](screenshots/issue_new-mobile.png) |
| issue_detail.html | [Freezer temperature alert](pages/issue_detail.html) | [PNG](screenshots/issue_detail-desktop.png) | [PNG](screenshots/issue_detail-mobile.png) |
| inspections.html | [Store inspections](pages/inspections.html) | [PNG](screenshots/inspections-desktop.png) | [PNG](screenshots/inspections-mobile.png) |
| inspection_form.html | [Daily store check](pages/inspection_form.html) | [PNG](screenshots/inspection_form-desktop.png) | [PNG](screenshots/inspection_form-mobile.png) |
| compliance.html | [Permits](pages/compliance.html) | [PNG](screenshots/compliance-desktop.png) | [PNG](screenshots/compliance-mobile.png) |
| planogram.html | [Planogram](pages/planogram.html) | [PNG](screenshots/planogram-desktop.png) | [PNG](screenshots/planogram-mobile.png) |
| employees.html | [Employees](pages/employees.html) | [PNG](screenshots/employees-desktop.png) | [PNG](screenshots/employees-mobile.png) |
| users.html | [Users & access](pages/users.html) | [PNG](screenshots/users-desktop.png) | [PNG](screenshots/users-mobile.png) |
| settings.html | [Workspace settings](pages/settings.html) | [PNG](screenshots/settings-desktop.png) | [PNG](screenshots/settings-mobile.png) |
| suppliers.html | [Suppliers](pages/suppliers.html) | [PNG](screenshots/suppliers-desktop.png) | [PNG](screenshots/suppliers-mobile.png) |
| products.html | [Product setup](pages/products.html) | [PNG](screenshots/products-desktop.png) | [PNG](screenshots/products-mobile.png) |
| sync.html | [Connections & sync](pages/sync.html) | [PNG](screenshots/sync-desktop.png) | [PNG](screenshots/sync-mobile.png) |
| dq.html | [Data quality](pages/dq.html) | [PNG](screenshots/dq-desktop.png) | [PNG](screenshots/dq-mobile.png) |
| audit.html | [Activity log](pages/audit.html) | [PNG](screenshots/audit-desktop.png) | [PNG](screenshots/audit-mobile.png) |
| assistant.html | [Ask Retail OS](pages/assistant.html) | [PNG](screenshots/assistant-desktop.png) | [PNG](screenshots/assistant-mobile.png) |
| ai_output.html | [Daily briefing](pages/ai_output.html) | [PNG](screenshots/ai_output-desktop.png) | [PNG](screenshots/ai_output-mobile.png) |
| ai_metrics.html | [Assistant performance](pages/ai_metrics.html) | [PNG](screenshots/ai_metrics-desktop.png) | [PNG](screenshots/ai_metrics-mobile.png) |
| notifications.html | [Notifications](pages/notifications.html) | [PNG](screenshots/notifications-desktop.png) | [PNG](screenshots/notifications-mobile.png) |
| login.html | [Sign in](pages/login.html) | [PNG](screenshots/login-desktop.png) | [PNG](screenshots/login-mobile.png) |
| password.html | [Change password](pages/password.html) | [PNG](screenshots/password-desktop.png) | [PNG](screenshots/password-mobile.png) |
| error.html | [This page is unavailable](pages/error.html) | [PNG](screenshots/error-desktop.png) | [PNG](screenshots/error-mobile.png) |
| source_unavailable.html | [Not available for Loyverse](pages/source_unavailable.html) | [PNG](screenshots/source_unavailable-desktop.png) | [PNG](screenshots/source_unavailable-mobile.png) |
| Extra interaction state | [Import StoreHub export](pages/import_csv.html) | [PNG](screenshots/import_csv-desktop.png) | [PNG](screenshots/import_csv-mobile.png) |
| Extra interaction state | [Record an expiry batch](pages/record_batch.html) | [PNG](screenshots/record_batch-desktop.png) | [PNG](screenshots/record_batch-mobile.png) |
| Extra interaction state | [Why this number?](pages/why_number.html) | [PNG](screenshots/why_number-desktop.png) | [PNG](screenshots/why_number-mobile.png) |
| Extra interaction state | [Assistant chat](pages/assistant_chat.html) | [PNG](screenshots/assistant_chat-desktop.png) | [PNG](screenshots/assistant_chat-mobile.png) |
