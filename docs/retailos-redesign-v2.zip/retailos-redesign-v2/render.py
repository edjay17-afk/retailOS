"""Render the offline prototype and verify every page at desktop/mobile sizes."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
results=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(channel='msedge',headless=True)
    page=browser.new_page(device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.route('https://**',lambda r:r.abort())
    page.route('http://**',lambda r:r.abort())
    for device,width,height in [('desktop',1440,1000),('mobile',390,844)]:
        page.set_viewport_size({'width':width,'height':height})
        for i,item in enumerate(manifest):
            page.goto((root/item['preview']).as_uri())
            page.evaluate('document.fonts.ready')
            overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth')
            page.screenshot(path=str(root/item[device]),full_page=device=='desktop')
            results.append(dict(page=item['id'],device=device,horizontal_overflow=overflow))
            if (i+1)%15==0:print(f'{device}: {i+1}/{len(manifest)} rendered',flush=True)
    page.set_viewport_size({'width':1440,'height':1000})
    page.goto((root/'index.html').as_uri())
    page.screenshot(path=str(root/'gallery-preview.png'))
    page.get_by_role('button',name='Inventory',exact=True).click()
    assert page.locator('.card:visible').count()==sum(x['module']=='Inventory' for x in manifest)
    page.get_by_role('button',name='Show mobile',exact=True).click()
    assert page.locator('body.mobile').count()==1
    page.goto((root/'pages/dashboard.html').as_uri())
    page.set_viewport_size({'width':390,'height':844})
    page.get_by_role('button',name='More pages',exact=True).click()
    assert page.locator('#navigation-dialog').is_visible()
    page.get_by_role('button',name='Close',exact=True).click()
    assert not page.locator('#navigation-dialog').is_visible()
    browser.close()
report={'screens':len(manifest),'screenshots':len(results),'page_errors':errors,'overflow_failures':[x for x in results if x['horizontal_overflow']],'results':results}
(root/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='results'}))
assert not errors and not report['overflow_failures']
