from datetime import date, datetime, timezone
from app.services.lark_inspections import parse_records, store_key
from tests.test_web import client, add_user, login
from app.models import Location

def test_store_and_philippine_date_match():
    stamp=int(datetime(2026,10,18,16,30,tzinfo=timezone.utc).timestamp()*1000)
    rows=[{"record_id":"rec1","fields":{"Store Store":"The Daily Centro Bantayan","Date Date":stamp,"Photos":[{"file_token":"file"}]}}]
    reports=parse_records(rows,date(2026,10,19))
    assert len(reports)==1 and reports[0]["time"]=="00:30" and reports[0]["attachments"]==1
    assert store_key("The Daily Centro - Bantayan")==reports[0]["store"]
    assert not parse_records(rows,date(2026,10,18))
    assert not parse_records([{"fields":{"Store":"Bantayan","Date":"bad"}}],date(2026,10,19))

def test_endpoint_scopes_reports(client,session,monkeypatch):
    from app.services import lark_inspections
    a=Location(name="The Daily Centro - Bantayan",storehub_id="LARK_A",type="store",monitored=True)
    b=Location(name="The Daily Centro - Tabunoc",storehub_id="LARK_B",type="store",monitored=True)
    session.add_all([a,b]);session.commit()
    add_user(session,"lark_reader","staff",[a.id]);login(client,"lark_reader")
    monkeypatch.setattr(lark_inspections,"reports_for_day",lambda day:{"available":True,"reports":[{"store":"bantayan","id":"a"},{"store":"tabunoc","id":"b"}],"checked_at":"10:00"})
    r=client.get('/inspections/lark-reports?on=2026-10-19')
    assert r.status_code==200
    assert set(r.json()["reports"])=={str(a.id)}
    assert client.get('/inspections/lark-reports?loc='+str(b.id)).status_code==403
    def fail(day):raise RuntimeError('private error')
    monkeypatch.setattr(lark_inspections,"reports_for_day",fail)
    r=client.get('/inspections/lark-reports').json()
    assert not r['available'] and 'private' not in r['message']
